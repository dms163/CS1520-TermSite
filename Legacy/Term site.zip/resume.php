<?php
$pageTitle = 'Resume';
include('header.html');
?>

<div id = "content">
    <p>
        <br>
        <embed src="Resume.pdf" width="800px" height="2100px"></embed>
    </p>
</div>
</body>
