<?php
$pageTitle = 'About me';
include('header.html');
?>

<div id = "content">
    <p>
       As stated before, my name is David Sweeney. I am a member of the university swimming and diving team. I am a CS major with a minor in history.
       I am from Kennesaw, GA and have only lived outside the south these past four years. I am a member of the Pitt computer science club.
    </p>
</div>
<div id = "content">
</div>
</body>
