<?php
    $pageTitle = 'Home';
    include('header.html');
?>
<div id = "content">
    <p>
        <h1>Hello and welcome to my website!</h1>
        <br>
        My name is David Sweeney.
        <br>
        Feel free to take a look around!
        <br>
    </p>
    <img src="Sweeney.jpg" alt="Loading..." >
</div>
</body>
